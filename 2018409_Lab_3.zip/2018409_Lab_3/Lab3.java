import java.io.*;
import java.util.*;

//Saad Ahmad
//2018409

class Lab3{
    public static ArrayList<Game> allUsers = new ArrayList<Game>();
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome to ArchLegends");
        System.out.println("Choose your option");
        System.out.println("1) New User");
        System.out.println("2) Existing User");
        System.out.println("3) Exit");
        int uChoice = s.nextInt();
        System.out.println("Enter Username");
        String uString= s.next();
        System.out.println("Choose a Hero");
        System.out.println("1) Warrior");
        System.out.println("2) Thief");
        System.out.println("3) Mage");
        System.out.println("4) Healer");
        int index = -1;
        int hChoice = s.nextInt();
        if(uChoice==1){
            if(hChoice==1){
                Hero newHero = new Warrior();
                Game newObj = new Game(newHero);
                newObj.setUsername(uString);
                allUsers.add(newObj);
                System.out.println("User Creation done. Username: "+newObj.getUsername()+". Hero type: Warrior. Log in to play the game . Exiting");
                uChoice= existingUser();
            }
            else if(hChoice==2){
                Hero newHero = new Thief();
                Game newObj = new Game(newHero);
                newObj.setUsername(uString);
                allUsers.add(newObj);
                System.out.println("User Creation done. Username: "+newObj.getUsername()+". Hero type: Thief. Log in to play the game . Exiting");
                uChoice= existingUser();
            }
            else if(hChoice==3){
                Hero newHero = new Mage();
                Game newObj = new Game(newHero);
                newObj.setUsername(uString);
                allUsers.add(newObj);
                System.out.println("User Creation done. Username: "+newObj.getUsername()+". Hero type: Mage. Log in to play the game . Exiting");
                uChoice= existingUser();
            }
            else{
                Hero newHero = new Healer();
                Game newObj = new Game(newHero);
                newObj.setUsername(uString);
                allUsers.add(newObj);
                System.out.println("User Creation done. Username: "+newObj.getUsername()+". Hero type: Healer. Log in to play the game . Exiting");
                uChoice= existingUser();
            }
        }
        if(uChoice==2){
            index = searchUser();
            System.out.println("User found...logging in");
        }
        if(allUsers.get(index).playGame()){
            System.out.println("Game Won");
        }
    }

    public static int existingUser(){
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome to ArchLegends");
        System.out.println("Choose your option");
        System.out.println("1) New User");
        System.out.println("2) Existing User");
        System.out.println("3) Exit");
        int uChoice = s.nextInt();
        return uChoice;
    }
    public static int searchUser(){
        Scanner s = new Scanner(System.in);        
        System.out.println("Enter Username");
        String toFind = s.next();
        Iterator<Game> userIter = allUsers.iterator();
        int count=0;
        while(userIter.hasNext()){
            Game temp = userIter.next();
            if(temp.getUsername().equals(toFind)){
                break;
            }
            count++;
        }
        return count;
    }
}

class Game{
    private String username;
    private static ArrayList<Monster> path;
    private Random r = new Random();
    public static Hero ourHero;
    private int numLocationsVis = 0;
    private boolean gameWon=false;

    public Game(Hero h){
        path = new ArrayList<Monster>();
        Monster first = new Goblin();
        Monster last = new Lionfang();
        path.add(first);
        path.add(rMonster());
        path.add(rMonster());
        path.add(rMonster());
        path.add(rMonster());
        path.add(rMonster());
        path.add(rMonster());
        path.add(rMonster());
        path.add(last);
        ourHero = h;
    }

    public boolean playGame(){
        Scanner s = new Scanner(System.in);
        int prev2=-1;
        int prev3=-1;
        int cameFromThis=0;
        int choice=0;
        boolean fightWon = false;
        System.out.println("You are at the starting location. Choose path:");
        int rInt1 = r.nextInt(path.size()-1);
        int rInt2 = r.nextInt(path.size()-1);
        while(rInt1==rInt2 || rInt1==cameFromThis || rInt2==cameFromThis){
            rInt1 = r.nextInt(path.size()-1);
            rInt2 = r.nextInt(path.size()-1);
        }
        System.out.println("1) Go to Location "+cameFromThis);
        System.out.println("2) Go to Location "+rInt1);
        System.out.println("3) Go to Location "+rInt2);
        System.out.println("Enter -1 to exit");
        choice = s.nextInt();
        if(choice==1){System.out.println("Moving to location "+cameFromThis);
        if(fight(cameFromThis)){numLocationsVis++;fightWon=true;}
        }
        else if(choice==2){System.out.println("Moving to location "+rInt1);
        if(fight(rInt1)){
            numLocationsVis++;
            fightWon=true;
        }
        cameFromThis = rInt1;
        }
        else{System.out.println("Moving to location "+rInt2);
            if(fight(rInt2)){
                numLocationsVis++;
                fightWon=true;
            }
            cameFromThis = rInt2;
        }
        while(choice!=-1 && gameWon==false){
            if(fightWon==false){
                if(fight(cameFromThis)){
                    fightWon=true;
                }
            }
            else if(numLocationsVis<3){
                fightWon=false;
                System.out.println("You are at location "+cameFromThis+" Choose path:");
                rInt1 = r.nextInt(path.size()-1);
                rInt2 = r.nextInt(path.size()-1);
                int rInt3 = r.nextInt(path.size()-1);
                while(rInt1==rInt3 || rInt1==rInt2 || rInt2==rInt3 || rInt1==cameFromThis || rInt2==cameFromThis || rInt3==cameFromThis){
                    rInt1 = r.nextInt(path.size()-1);
                    rInt2 = r.nextInt(path.size()-1);
                    rInt3 = r.nextInt(path.size()-1);
                }
                System.out.println("1) Go to Location "+rInt1);
                System.out.println("2) Go to Location "+rInt2);
                System.out.println("3) Go to Location "+rInt3);
                System.out.println("4) Go back");
                System.out.println("Enter -1 to exit");
                choice = s.nextInt();
                if(choice==1){
                    System.out.println("Moving to location "+rInt1);
                    if(fight(rInt1)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = rInt1;
                    }
                }
                else if(choice==2){
                    System.out.println("Moving to location "+rInt2);
                    if(fight(rInt2)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = rInt2;
                    }
                }
                else if(choice==3){
                    System.out.println("Moving to location "+rInt3);
                    if(fight(rInt3)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = rInt3;
                    }
                }
                else if(choice==4){
                    System.out.println("Moving to location "+cameFromThis);
                    if(fight(cameFromThis)){
                        fightWon=true;
                        numLocationsVis++;
                    }
                }
            }
            else if(numLocationsVis>=4){
                fightWon=false;
                System.out.println("You are at location "+cameFromThis+" Choose path:");
                rInt1 = r.nextInt(path.size()-1);
                rInt2 = r.nextInt(path.size()-1);
                while(rInt1==rInt2 || rInt1==cameFromThis || rInt2==cameFromThis){
                    rInt1 = r.nextInt(path.size()-1);
                    rInt2 = r.nextInt(path.size()-1);
                }
                System.out.println("1) Go to Location "+rInt1);
                System.out.println("2) Go to Location "+rInt2);
                System.out.println("3) Go to Location "+(path.size()-1));
                System.out.println("4) Go back");
                System.out.println("Enter -1 to exit");
                choice = s.nextInt();
                if(choice==1){
                    System.out.println("Moving to location "+rInt1);
                    if(fight(rInt1)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = rInt1;
                    }
                }
                else if(choice==2){
                    System.out.println("Moving to location "+rInt2);
                    if(fight(rInt2)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = rInt2;
                    }
                }
                else if(choice==3){
                    System.out.println("Moving to location "+(path.size()-1));
                    if(fight(path.size()-1)){
                        fightWon=true;
                        numLocationsVis++;
                        cameFromThis = path.size()-1;
                    }
                }
                else if(choice==4){
                    System.out.println("Moving to location "+cameFromThis);
                    if(fight(cameFromThis)){
                        fightWon=true;
                        numLocationsVis++;
                    }
                }
            }
        }
        if(gameWon){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean fightBoss(){
        Scanner s = new Scanner(System.in);
        System.out.println("Fight Started. Your fighting a level "+(path.get(path.size()-1)).level+" Monster.");
        Monster temp = path.get(path.size()-1);
        ourHero.setCurrMonster(temp);
        while(ourHero.getHp()>0 && ourHero.getCurrMonster().getHp()>0){
        System.out.println("Choose move:");
        System.out.println("1) Attack");
        System.out.println("2) Defense");
        if(ourHero.getNumMoves()>=3){
            System.out.println("3)Special Attack");
        }
        int choice = s.nextInt();
        if(choice==1){
            System.out.println("You choose to attack");
            ourHero.attack();
            System.out.println("You attacked and inflicted "+ourHero.getAttackAttr()+" damage to the monster.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
            System.out.println("Monster attack!");
            ourHero.getCurrMonster().attack();
            ourHero.getCurrMonster().sAttack();
            System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
        }
        else if(choice==2){
            System.out.println("You choose to defense");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
            System.out.println("Monster Attack!");
            ourHero.getCurrMonster().attackonDefense(ourHero.defense());
            ourHero.getCurrMonster().sAttack();
            System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
        }
        else if(choice==3){
            if(ourHero.isCount3()){
                for(int i=0;i<3;i++){
                    System.out.println("Choose move:");
                    System.out.println("1) Attack");
                    System.out.println("2) Defense");
                    int sChoice = s.nextInt();
                    ourHero.sPower();
                    if(sChoice==1){
                        System.out.println("You choose to attack");
                        ourHero.attack();
                        System.out.println("You attacked and inflicted "+ourHero.getAttackAttr()+" damage to the monster.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                        System.out.println("Monster attack!");
                        ourHero.getCurrMonster().attack();
                        ourHero.getCurrMonster().sAttack();
                        System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                    }
                    else if(sChoice==2){
                        System.out.println("You choose to defense");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                        System.out.println("Monster Attack!");
                        ourHero.getCurrMonster().attackonDefense(ourHero.defense());
                        ourHero.getCurrMonster().sAttack();
                        System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                    }
                    ourHero.reset();
                }
            }
            else{
                System.out.println("You have stolen "+((ourHero.getCurrMonster().getHp())*(0.3))+" hp from monster");
                ourHero.sPower();
                System.out.println("Special power active");
                System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                System.out.println("Monster attack!");
                ourHero.getCurrMonster().attack();
                ourHero.getCurrMonster().sAttack();
                System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                ourHero.reset();
            }
            ourHero.setNumMoves(0);
        }
        } 
        if(ourHero.getHp()<=0){
            System.out.println("You died");
            return false;
        }  
        else{
            System.out.println("Lionfang killed!");
            int xpAdd = (ourHero.getCurrMonster().getLevel())*20;
            System.out.println(xpAdd+" XP awarded");
            System.out.println("Level Up: level: "+(ourHero.getCurrLevel()+1));
            if(ourHero.getXp()+xpAdd==20){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(150);
                ourHero.setMaxHp(150);
            }
            else if(ourHero.getXp()+xpAdd==40){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(200);
                ourHero.setMaxHp(200);
            }
            else if(ourHero.getXp()+xpAdd==60){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(250);
                ourHero.setMaxHp(250);
            }
            gameWon = true;
            return true;
        }
    }

    public boolean fight(int n){
        Scanner s = new Scanner(System.in);
        System.out.println("Fight Started. Your fighting a level "+(path.get(n)).level+" Monster.");
        Monster temp = path.get(n);
        ourHero.setCurrMonster(temp);
        while(ourHero.getHp()>0 && ourHero.getCurrMonster().getHp()>0){
        System.out.println("Choose move:");
        System.out.println("1) Attack");
        System.out.println("2) Defense");
        if(ourHero.getNumMoves()>=3){
            System.out.println("3)Special Attack");
        }
        int choice = s.nextInt();
        if(choice==1){
            System.out.println("You choose to attack");
            ourHero.attack();
            System.out.println("You attacked and inflicted "+ourHero.getAttackAttr()+" damage to the monster.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
            System.out.println("Monster attack!");
            ourHero.getCurrMonster().attack();
            System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
        }
        else if(choice==2){
            System.out.println("You choose to defense");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
            System.out.println("Monster Attack!");
            ourHero.getCurrMonster().attackonDefense(ourHero.defense());
            System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
            System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
        }
        else if(choice==3){
            if(ourHero.isCount3()){
                for(int i=0;i<3;i++){
                    System.out.println("Choose move:");
                    System.out.println("1) Attack");
                    System.out.println("2) Defense");
                    int sChoice = s.nextInt();
                    ourHero.sPower();
                    if(sChoice==1){
                        System.out.println("You choose to attack");
                        ourHero.attack();
                        System.out.println("You attacked and inflicted "+ourHero.getAttackAttr()+" damage to the monster.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                        System.out.println("Monster attack!");
                        ourHero.getCurrMonster().attack();
                        System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                    }
                    else if(sChoice==2){
                        System.out.println("You choose to defense");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                        System.out.println("Monster Attack!");
                        ourHero.getCurrMonster().attackonDefense(ourHero.defense());
                        System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                        System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                    }
                    ourHero.reset();
                }
            }
            else{
                System.out.println("You have stolen "+((ourHero.getCurrMonster().getHp())*(0.3))+" hp from monster");
                ourHero.sPower();
                System.out.println("Special power active");
                System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                System.out.println("Monster attack!");
                ourHero.getCurrMonster().attack();
                ourHero.getCurrMonster().sAttack();
                System.out.println("The monster attacked and inflicted "+ourHero.getCurrMonster().inflictedDamage+" damage to you.");
                System.out.println("Your Hp: "+ourHero.getHp()+"/"+ourHero.getMaxHp()+" Monsters Hp: "+ourHero.getCurrMonster().getHp()+"/"+ourHero.getCurrMonster().getMaxHP());
                ourHero.reset();
            }
            ourHero.setNumMoves(0);
        }
        } 
        if(ourHero.getHp()<=0){
            System.out.println("You died");
            return false;
        }  
        else{
            System.out.println("Monster killed!");
            int xpAdd = (ourHero.getCurrMonster().getLevel())*20;
            System.out.println(xpAdd+" XP awarded");
            System.out.println("Level Up: level: "+(ourHero.getCurrLevel()+1));
            if(ourHero.getXp()+xpAdd==20){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(150);
                ourHero.setMaxHp(150);
            }
            else if(ourHero.getXp()+xpAdd==40){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(200);
                ourHero.setMaxHp(200);
            }
            else if(ourHero.getXp()+xpAdd==60){
                ourHero.setCurrLevel(ourHero.getCurrLevel()+1);
                ourHero.setXp(ourHero.getXp()+xpAdd);
                ourHero.setHp(250);
                ourHero.setMaxHp(250);
            }
            return true;
        }
    }

    public Monster rMonster(){
        int c = r.nextInt(3)+1;
        if(c==1){
            Monster tempG = new Goblin();
            return tempG;
        }
        else if(c==2){
            Monster tempZ = new Zombies();
            return tempZ;
        }
        else{
            Monster tempF = new Fiends();
            return tempF;
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

class Monster{
    protected int level;
    protected int hp;
    public int inflictedDamage;
    protected int maxHP;

    public void attack(){
        int peak = hp/8;
        int upper = hp/4;
        Random r = new Random();
        int attackVal = (int)r.nextGaussian()+peak;
        if(attackVal>upper){
            attackVal = upper;
        }
        else if(attackVal<0){
            attackVal = 1;
        }
        inflictedDamage = attackVal;
        Game.ourHero.setHp(Game.ourHero.getHp()-attackVal);
    }

    public void sAttack(){
        // Only for Lionfang
    }

    public void attackonDefense(int toSub){
        int peak = hp/8;
        int upper = hp/4;
        Random r = new Random();
        int attackVal = ((int)r.nextGaussian()+peak)-toSub;
        if(attackVal>upper){
            attackVal = upper;
        }
        else if(attackVal<0){
            attackVal = 1;
        }
        inflictedDamage = attackVal;
        Game.ourHero.setHp(Game.ourHero.getHp()-attackVal);
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getMaxHP() {
        return maxHP;
    }

    public void setMaxHP(int maxHP) {
        this.maxHP = maxHP;
    }
}

class Goblin extends Monster{
    public Goblin(){
        hp = 100;
        level = 1;
        maxHP = 100;
    }
}

class Zombies extends Monster{
    public Zombies(){
        hp = 100;
        level = 2;
        maxHP = 100;
    }
}
class Fiends extends Monster{
    public Fiends(){
        hp = 200;
        level = 3;
        maxHP = 200;
    }
}
class Lionfang extends Monster{
    public Lionfang(){
        hp = 250;
        level = 4;
        maxHP = 250;
    }

    @Override
    public void sAttack(){
        boolean ans = false;
        Random r = new Random();
        int rInt = r.nextInt(10);
        if(rInt==5){
            ans = true;
        }
        if(ans){
            System.out.println("Lionfang special attack activated");
            Game.ourHero.setHp((Game.ourHero.getHp())/2);
        }
    }
}

class Hero{
    protected int currLevel;
    protected int hp;
    protected int xp;
    protected Monster currMonster;
    protected int attackAttr;
    protected int defenseAttr;
    protected int numMoves;
    protected boolean specialActive;
    protected boolean count3;
    protected int maxHp;

    public void attack(){
        currMonster.setHp(currMonster.getHp()-attackAttr); 
        numMoves++;
    }
    public void reset(){
        // Used in child
    }

    public void sPower(){
        // Do nothing
    }
    public int defense(){
        numMoves++;
        return defenseAttr;
    }
    public int getCurrLevel() {
        return currLevel;
    }

    public void setCurrLevel(int currLevel) {
        this.currLevel = currLevel;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }

    public Monster getCurrMonster() {
        return currMonster;
    }

    public void setCurrMonster(Monster currMonster) {
        this.currMonster = currMonster;
    }

    public int getNumMoves() {
        return numMoves;
    }

    public void setNumMoves(int numMoves) {
        this.numMoves = numMoves;
    }

    public boolean isSpecialActive() {
        return specialActive;
    }

    public void setSpecialActive(boolean specialActive) {
        this.specialActive = specialActive;
    }

    public boolean isCount3() {
        return count3;
    }

    public int getAttackAttr() {
        return attackAttr;
    }

    public void setAttackAttr(int attackAttr) {
        this.attackAttr = attackAttr;
    }

    public int getDefenseAttr() {
        return defenseAttr;
    }

    public void setDefenseAttr(int defenseAttr) {
        this.defenseAttr = defenseAttr;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }
}

class Warrior extends Hero{
   
    public Warrior(){
        attackAttr=10;
        defenseAttr=3;
        hp=100;
        xp=0;
        currLevel=1;
        numMoves=0;
        specialActive=false;
        count3=true;
        maxHp=100;
    }
    @Override
    public void reset(){
        attackAttr = 10;
        defenseAttr = 3;
    }
    @Override
    public void sPower(){
        attackAttr+=5;
        defenseAttr+=5;
    }
}

class Mage extends Hero{
    public Mage(){
        attackAttr=5;
        defenseAttr=5;
        hp=100;
        xp=0;
        currLevel=1;
        numMoves=0;
        specialActive=false;
        count3=true;
        maxHp=100;
    }
    @Override
    public void reset(){
        attackAttr = 5;
        defenseAttr = 5;
    }
    @Override
    public void sPower(){
        currMonster.setHp(currMonster.getHp() - (int)((currMonster.getHp())/20));
    }
}

class Thief extends Hero{ 
    public Thief(){
        attackAttr=6;
        defenseAttr=4;
        hp=100;
        xp=0;
        currLevel=1;
        numMoves=0;
        specialActive=false;
        count3=false;
        maxHp=100;
    } 
    @Override  
    public void sPower(){
        int thirty = (int)(((currMonster.getHp())*0.3));
        int toSteal = currMonster.getHp() - thirty;
        currMonster.setHp(toSteal);
        hp+= thirty;
    }
    @Override
    public void reset(){
        attackAttr = 6;
        defenseAttr = 4;
    }
}

class Healer extends Hero{
    public Healer(){
        attackAttr=4;
        defenseAttr=8;
        hp=100;
        xp=0;
        currLevel=1;
        numMoves=0;
        maxHp=100;
        specialActive=false;
        count3=true;
    }
    @Override
    public void reset(){
        attackAttr = 4;
        defenseAttr = 8;
    }
    @Override
    public void sPower(){
        hp += (int)(hp/20);
    }
}

