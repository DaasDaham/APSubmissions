import java.io.*;
import java.util.*;

// Saad Ahmad
// 2018409

class SnakeBiteException extends RuntimeException{
    public SnakeBiteException(String message){
        super(message);
    }
}
class VultureBiteException extends RuntimeException{
    public VultureBiteException(String message){
        super(message);
    }
}
class CricketBiteException extends RuntimeException{
    public CricketBiteException(String message){
        super(message);
    }
}
class TrampolineException extends RuntimeException{
    public TrampolineException(String message){
        super(message);
    }
}
class GameWinnerException extends RuntimeException{
    public GameWinnerException(String message){
        super(message);
    }
}

class Lab5{
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter total number of tracks on race course (length)");
        int nu = s.nextInt();
        while(nu<20){
            System.out.println("Enter a greater length");
            nu = s.nextInt();
        }
        Game o = new Game(nu);     
        try {
            o.playGame();
        } catch (GameWinnerException e) {
            System.out.println(e.getMessage());
            System.out.println(">>              Total Snake Bites = "+o.getsBites());
            System.out.println(">>              Total Vulture Bites = "+o.getvBites());
            System.out.println(">>              Total Cricket Bites = "+o.getcBites());
            System.out.println(">>              Total Trampoline Jumps = "+o.gettBites());
        }
    }
}

class Game{
    private int numTiles;
    private int nSnake = 0;
    private int nVult = 0;
    private int nCric = 0;
    private int nWhite = 0;
    private int nTramp = 0;
    public static int sJumps;
    public static int vJumps;
    public static int cJumps;
    public static int tJumps;
    private int sBites=0;
    private int vBites=0;
    private int cBites=0;
    private int tBites=0;
    private String playerName;
    public static Random rg = new Random();
    private ArrayList<Tiles> gameList;
    public Game(int n){
        numTiles = n;
        setJumps();
        gameList = new ArrayList<Tiles>();
        gameList.add(new White());
        for(int i=1;i<numTiles;i++){
            gameList.add(randTile());
        }
    }

    public static void setJumps(){
        vJumps = rg.nextInt(10)+1;
        sJumps = rg.nextInt(10)+1;
        cJumps = rg.nextInt(10)+1;
        tJumps = rg.nextInt(10)+1;
    }

    public void playGame() throws GameWinnerException{
        Scanner s = new Scanner(System.in);
        System.out.println("Setting up race track...");
        System.out.println("Danger, there are "+nSnake+", "+nCric+", "+nVult+" number of snakes, cricket and Vultures respectively on your track!");
        System.out.println("Danger: Each snake, cricket and Vultures can throw you back by "+sJumps+", "+cJumps+", "+vJumps+" number of Tiles respectively!");
        System.out.println("Good news: There are "+nTramp+" number of trampoline on your track");
        System.out.println("Good news: Each Trampoline can help you advance by "+tJumps+" number of Tiles");
        System.out.println("Enter player name");
        playerName = s.next();
        System.out.println("Starting the game with "+playerName+" for rolling the Dice at Tile-1");
        System.out.println("Control transferred to computer for rolling dice for "+playerName);
        System.out.println("Hit enter to start game");
        System.out.println("Game Started ==================>");
        int numRolls=1;
        boolean outOfCage = false;
        int pos=1;
        while(true){
            if(!outOfCage){
                int roll = rollDice();
                if(roll==6){
                    System.out.println(">>[Roll- "+numRolls+"]: "+playerName+" rolled "+roll+" at Tile-"+pos+" You are out of the cage! You get a free roll");
                    outOfCage = true;
                    numRolls++;
                }
                else{
                    System.out.println(">>[Roll- "+numRolls+"]: "+playerName+" rolled "+roll+" at Tile-"+pos+",OOPs you need 6 to start");
                    numRolls++;
                }
            }
            else{
                int roll = rollDice();
                pos+=roll;
                if(pos>numTiles){
                    System.out.println(">>[Roll- "+numRolls+"]: "+playerName+" rolled "+roll+" at Tile-"+(pos-roll)+" landed on Tile "+(pos-roll));
                    numRolls++;
                    pos-=roll;
                }
                else{
                    System.out.println(">>[Roll- "+numRolls+"]: "+playerName+" rolled "+roll+" at Tile-"+(pos-roll)+" landed on Tile "+(pos));
                if(pos==numTiles){
                    throw new GameWinnerException(">>               Josh wins the race in "+numRolls+" moves");
                }
                if(pos<numTiles){
                    numRolls++;
                System.out.println(">>      Trying to shake the Tile-"+pos);
                try {
                    gameList.get(pos-1).shake();
                    pos+=(gameList.get(pos-1).getNumJumps());
                    System.out.println(">>      Josh moved to tile-"+pos);
                } catch (SnakeBiteException e) {
                    System.out.println(e.getMessage());
                    sBites++;
                    pos-=(gameList.get(pos-1).getNumJumps());
                    if(pos<=0){
                        System.out.println(">>      "+playerName+" moved to Tile-1 as it can't go back further");
                        outOfCage = true;
                        pos = 1;
                    }
                    else{
                        System.out.println(">>      "+playerName+" moved to Tile-"+pos);
                    }
                } catch (CricketBiteException e) {
                    System.out.println(e.getMessage());
                    cBites++;
                    pos-=(gameList.get(pos-1).getNumJumps());
                    if(pos<=0){
                        System.out.println(">>      "+playerName+" moved to Tile-1 as it can't go back further");
                        outOfCage = true;
                        pos = 1;
                    }
                    else{
                        System.out.println(">>      "+playerName+" moved to Tile-"+pos);
                    }
                } catch (VultureBiteException e) {
                    System.out.println(e.getMessage());
                    vBites++;
                    pos-=(gameList.get(pos-1).getNumJumps());
                    if(pos<=0){
                        System.out.println(">>      "+playerName+" moved to Tile-1 as it can't go back further");
                        outOfCage = true;
                        pos = 1;
                    }
                    else{
                        System.out.println(">>      "+playerName+" moved to Tile-"+pos);
                    }
                } catch (TrampolineException e) {
                    System.out.println(e.getMessage());
                    tBites++;
                    pos+=(gameList.get(pos-1).getNumJumps());
                    if(pos>=numTiles){
                        //System.out.println(">>          "+playerName+" wins the race in "+numRolls);
                        throw new GameWinnerException(">>               Josh wins the race in "+numRolls+" moves");
                    }
                    else{
                        System.out.println(">>      "+playerName+" moved to Tile-"+pos);
                    }
                }
            }
                }
            }
        }
    }

    public int rollDice(){
        int toReturn = rg.nextInt(6)+1;
        return toReturn;
    }

    public Tiles randTile(){
        int check = rg.nextInt(10)+1;
        if(check==5){
            Tiles sObj = new Snake();
            nSnake++;
            return sObj;
        }
        else if(check==6){
            Tiles vObj = new Vulture();
            nVult++;
            return vObj;
        }
        else if(check==7){
            Tiles cObj = new Cricket();
            nCric++;
            return cObj;
        }
        else if(check==8){
            Tiles tObj = new Trampoline();
            nTramp++;
            return tObj;
        }
        else{
            Tiles wObj = new White();
            nWhite++;
            return wObj;
        }
    }

    public int getsBites() {
        return sBites;
    }

    public void setsBites(int sBites) {
        this.sBites = sBites;
    }

    public int getvBites() {
        return vBites;
    }

    public void setvBites(int vBites) {
        this.vBites = vBites;
    }

    public int getcBites() {
        return cBites;
    }

    public void setcBites(int cBites) {
        this.cBites = cBites;
    }

    public int gettBites() {
        return tBites;
    }

    public void settBites(int tBites) {
        this.tBites = tBites;
    }
}

abstract class Tiles{
    protected int numJumps;
    protected Random rt = new Random();

    public int getNumJumps() {
        return numJumps;
    }

    public void setNumJumps(int numJumps) {
        this.numJumps = numJumps;
    }

    public abstract void shake();
}

class Snake extends Tiles{
    public Snake(){
        numJumps = Game.sJumps;
    }
    @Override
    public void shake() throws SnakeBiteException{
        throw new SnakeBiteException(">>        Hiss...! Iam a snake, you go back "+numJumps+" tiles");
    }
}
class Vulture extends Tiles{
    public Vulture(){
        numJumps = Game.vJumps;
    }
    @Override
    public void shake() throws VultureBiteException{
        throw new VultureBiteException(">>      Yapping...! I am a vulture, you go back "+numJumps+" tiles");
    }
}
class Trampoline extends Tiles{
    public Trampoline(){
        numJumps = Game.tJumps;
    }
    @Override
    public void shake() throws TrampolineException{
        throw new TrampolineException(">>       PingPong! I am a trampoline, you advance "+numJumps+" tiles");
    }
}
class Cricket extends Tiles{
    public Cricket(){
        numJumps = Game.cJumps;
    }
    @Override
    public void shake() throws CricketBiteException{
        throw new CricketBiteException(">>      Chirp...! I am a cricket, you go back "+numJumps+" tiles");
    }
}
class White extends Tiles{
    public White(){
        numJumps = 0;
    }
    @Override
    public void shake(){
        System.out.println(">>      I am a white tile");
    }
}